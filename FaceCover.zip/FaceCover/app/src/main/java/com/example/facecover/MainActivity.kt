package com.example.facecover

import android.content.ContentValues
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import android.graphics.ImageDecoder
import kotlin.math.max

class MainActivity : ComponentActivity() {

    private lateinit var imageView: ImageView
    private lateinit var status: TextView
    private lateinit var seek: SeekBar
    private var original: Bitmap? = null
    private var result: Bitmap? = null
    private var faces: List<Rect> = emptyList()

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) load(uri)
    }

    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
            .setMinFaceSize(0.02f)
            .build()
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        val pick = Button(this).apply { text = "Importer une photo"; setOnClickListener {
            picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        } }
        status = TextView(this).apply { text = "Choisis une photo"; gravity = Gravity.CENTER }
        imageView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }
        val sizeLabel = TextView(this).apply { text = "Taille des carrés (marge autour du visage)" }
        // 100% -> 200% de la taille du visage, 130% par défaut
        seek = SeekBar(this).apply {
            max = 100; progress = 30
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) render() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        val save = Button(this).apply { text = "Enregistrer"; setOnClickListener { save() } }
        listOf(pick, status, imageView, sizeLabel, seek, save).forEach { root.addView(it) }
        setContentView(root)
    }

    private fun load(uri: Uri) {
        status.text = "Détection des visages…"
        val bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { d, info, _ ->
            d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val big = max(info.size.width, info.size.height)
            if (big > 3000) {
                val r = 3000f / big
                d.setTargetSize((info.size.width * r).toInt(), (info.size.height * r).toInt())
            }
        }
        original = bmp
        detector.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { list ->
                faces = list.map { it.boundingBox }
                status.text = "${faces.size} visage(s) détecté(s)"
                render()
            }
            .addOnFailureListener { status.text = "Erreur : ${it.message}" }
    }

    private fun render() {
        val src = original ?: return
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        val paint = Paint().apply { color = Color.BLACK; style = Paint.Style.FILL }
        val factor = 1f + seek.progress / 100f
        for (r in faces) {
            // Carré proportionnel à la taille de CHAQUE visage, centré dessus
            val side = max(r.width(), r.height()) * factor
            val cx = r.exactCenterX()
            val cy = r.exactCenterY()
            canvas.drawRect(cx - side / 2, cy - side / 2, cx + side / 2, cy + side / 2, paint)
        }
        result = out
        imageView.setImageBitmap(out)
    }

    private fun save() {
        val bmp = result ?: return
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "facecover_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FaceCover")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) { Toast.makeText(this, "Échec", Toast.LENGTH_SHORT).show(); return }
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        Toast.makeText(this, "Enregistrée dans Images/FaceCover", Toast.LENGTH_LONG).show()
    }
}
